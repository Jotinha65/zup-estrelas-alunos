package br.com.zup.estrelas.zup.estrelas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ZupEstrelasAlunosApplication {

	public static void main(String[] args) {
		SpringApplication.run(ZupEstrelasAlunosApplication.class, args);
	}

}
