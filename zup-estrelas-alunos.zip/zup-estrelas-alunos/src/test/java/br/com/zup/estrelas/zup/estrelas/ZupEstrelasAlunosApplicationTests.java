package br.com.zup.estrelas.zup.estrelas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZupEstrelasAlunosApplicationTests {

	@Test
	void contextLoads() {
	}

}
